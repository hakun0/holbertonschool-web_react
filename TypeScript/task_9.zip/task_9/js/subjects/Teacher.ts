namespace Subjects {
	export interface Teacher {
	  firstName: string;
	  lastName: string;
	}
  }
