# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e4]:
    - paragraph [ref=e5]: Here is the list of notifications
    - list [ref=e6]:
      - listitem [ref=e7]: New course available
      - listitem [ref=e8]: New resume available
      - listitem [ref=e9]:
        - strong [ref=e10]: Urgent requirement
        - text: "- complete by EOD"
    - button "Close" [ref=e11] [cursor=pointer]:
      - img "close" [ref=e12] [cursor=pointer]
  - generic [ref=e13]:
    - img "holberton logo" [ref=e14]
    - heading "School dashboard" [level=1] [ref=e15]
  - generic [ref=e16]:
    - paragraph [ref=e17]: Login to access the full dashboard
    - generic [ref=e18]:
      - generic [ref=e19]: "Email:"
      - textbox "Email:" [ref=e20]
      - generic [ref=e21]: "Password:"
      - textbox "Password:" [ref=e22]
      - button "OK" [ref=e23]
  - paragraph [ref=e25]: Copyright 2025 - Holberton School
```